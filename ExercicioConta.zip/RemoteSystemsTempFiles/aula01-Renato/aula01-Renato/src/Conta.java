
public class Conta {

	public Conta(){
		super(); // construtor da classe.
	}
	
	public void exibirMensagem(){
		System.out.println("Bem vindo � Conta");		
		}
		
	public static void main() {
			
		Conta c = new Conta();
		c.exibirMensagem();			
			
		}
	
}
